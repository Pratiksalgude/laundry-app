const mongoose = require('mongoose');

const garmentSchema = new mongoose.Schema({
  type: { type: String, required: true },
  quantity: { type: Number, required: true, min: 1 },
  pricePerItem: { type: Number, required: true, min: 0 }
}, { _id: false });

const orderSchema = new mongoose.Schema({
  orderId: {
    type: String,
    unique: true
  },
  customerName: {
    type: String,
    required: [true, 'Customer name is required'],
    trim: true
  },
  phoneNumber: {
    type: String,
    required: [true, 'Phone number is required'],
    trim: true
  },
  garments: {
    type: [garmentSchema],
    validate: [arr => arr.length > 0, 'At least one garment is required']
  },
  totalBill: {
    type: Number,
    required: true
  },
  status: {
    type: String,
    enum: ['RECEIVED', 'PROCESSING', 'READY', 'DELIVERED'],
    default: 'RECEIVED'
  },
  estimatedDelivery: {
    type: String
  },
  createdBy: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User'
  }
}, { timestamps: true });

// Auto-generate orderId and estimatedDelivery before saving
orderSchema.pre('save', function (next) {
  if (!this.orderId) {
    this.orderId = 'ORD-' + Math.random().toString(36).slice(2, 10).toUpperCase();
  }
  if (!this.estimatedDelivery) {
    const d = new Date();
    d.setDate(d.getDate() + 3);
    this.estimatedDelivery = d.toISOString().split('T')[0];
  }
  next();
});

module.exports = mongoose.model('Order', orderSchema);

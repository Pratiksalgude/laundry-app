@echo off
color 0A
title CleanSlate - Quick Start
echo.
echo  ============================================================
echo     🧺  CleanSlate — Quick Start
echo  ============================================================
echo.

:: Check if node_modules exists
if not exist "%~dp0backend\node_modules" (
    echo  ⚠️  Dependencies not installed! Running npm install first...
    cd /d "%~dp0backend"
    call npm install
    echo.
)

:: Check if .env exists
if not exist "%~dp0backend\.env" (
    echo  ❌ .env file missing! Please run setup_everything.bat first.
    pause
    exit
)

:: Open frontend
echo  🌐 Opening frontend...
start "" "%~dp0frontend\index.html"

:: Start server
echo  🚀 Starting server on http://localhost:5000
echo  Press Ctrl+C to stop.
echo.
cd /d "%~dp0backend"
call node server.js
pause

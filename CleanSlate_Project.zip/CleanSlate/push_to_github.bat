@echo off
color 0E
title CleanSlate - Push to GitHub
echo.
echo  ============================================================
echo     📤 CleanSlate — Push to GitHub
echo  ============================================================
echo.

:: Check if Git is installed
where git >nul 2>nul
if %errorlevel% neq 0 (
    echo  ❌ Git is not installed!
    echo.
    
    where winget >nul 2>nul
    if %errorlevel% equ 0 (
        echo  📥 Installing Git via winget...
        winget install Git.Git --accept-package-agreements --accept-source-agreements
        echo.
        echo  ⚠️  Please CLOSE this window and run push_to_github.bat AGAIN.
        pause
        exit
    )
    
    echo  📥 Please install Git manually:
    echo  👉 https://git-scm.com/download/win
    start https://git-scm.com/download/win
    pause
    exit
)

for /f "tokens=*" %%i in ('git --version') do set GIT_VER=%%i
echo  ✅ %GIT_VER%
echo.

:: Navigate to project root
cd /d "%~dp0"

:: Check if already a git repo
if exist ".git" (
    echo  ✅ Git repository already initialized.
) else (
    echo  📁 Initializing Git repository...
    git init
    echo  ✅ Git initialized!
)

:: Create .gitignore at root if not exists
if not exist ".gitignore" (
    echo node_modules/> .gitignore
    echo .env>> .gitignore
    echo .DS_Store>> .gitignore
    echo  ✅ Root .gitignore created
)

:: Stage all files
echo.
echo  📦 Staging all files...
git add .
echo  ✅ All files staged!

:: Show status
echo.
echo  📋 Files to be committed:
git status --short
echo.

:: Commit
echo  💾 Creating commit...
git commit -m "🧺 CleanSlate - Laundry Order Management System (AI-First)"
echo  ✅ Committed!

:: Set branch to main
git branch -M main

:: Ask for GitHub repo URL
echo.
echo  ============================================================
echo   📝 Enter your GitHub repository URL
echo   (Create one at: https://github.com/new)
echo.
echo   Example: https://github.com/yourusername/CleanSlate.git
echo  ============================================================
echo.
set /p REPO_URL="  GitHub repo URL: "

if "%REPO_URL%"=="" (
    echo  ❌ No URL provided. Skipping push.
    echo  You can push manually later:
    echo    git remote add origin YOUR_REPO_URL
    echo    git push -u origin main
    pause
    exit
)

:: Add remote and push
echo.
echo  🚀 Pushing to GitHub...
git remote remove origin >nul 2>nul
git remote add origin %REPO_URL%
git push -u origin main

if %errorlevel% equ 0 (
    echo.
    echo  ════════════════════════════════════════════════════════════
    echo   ✅ Successfully pushed to GitHub!
    echo   🔗 %REPO_URL%
    echo  ════════════════════════════════════════════════════════════
) else (
    echo.
    echo  ⚠️  Push failed. This might be because:
    echo   - You need to authenticate (GitHub will show a login prompt)
    echo   - The repository doesn't exist yet
    echo   - Create it at: https://github.com/new
    echo.
    echo  After creating the repo, try running this script again.
)

echo.
pause

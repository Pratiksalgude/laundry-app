# 🧺 CleanSlate — Laundry Order Management System

A lightweight, full-stack system for dry cleaning stores to **create orders**, **track status**, **calculate billing**, and **view dashboard analytics**.

Built as part of a Software Engineering Assignment with an **AI-First** approach.

---

## 📌 Tech Stack

| Layer | Technology |
|---|---|
| **Frontend** | Vanilla HTML, CSS, JavaScript |
| **Backend** | Node.js + Express.js |
| **Database** | MongoDB (Atlas - Cloud) |
| **Authentication** | JWT (JSON Web Tokens) + bcryptjs |
| **API Testing** | Postman Collection included |

---

## 🚀 Setup Instructions

### Prerequisites
- **Node.js** (v16 or above) — [Download](https://nodejs.org/)
- **MongoDB Atlas** account (free) — [Sign Up](https://www.mongodb.com/atlas)
- **Git** — [Download](https://git-scm.com/)

### Step 1: Clone the Repository
```bash
git clone https://github.com/yourusername/CleanSlate.git
cd CleanSlate
```

### Step 2: Setup Backend
```bash
cd backend
npm install
```

### Step 3: Configure Environment Variables
```bash
cp .env.example .env
```
Edit `.env` and add your MongoDB Atlas connection string:
```
MONGO_URI=mongodb+srv://<username>:<password>@cluster0.xxxxx.mongodb.net/cleanslate?retryWrites=true&w=majority
JWT_SECRET=your_super_secret_key_here
PORT=5000
```

> 💡 **How to get MONGO_URI:**
> 1. Create a free cluster on [MongoDB Atlas](https://www.mongodb.com/atlas)
> 2. Go to **Database Access** → Create a user
> 3. Go to **Network Access** → Allow your IP (or 0.0.0.0/0 for dev)
> 4. Click **Connect** → **Connect your application** → Copy the URI

### Step 4: Start the Backend Server
```bash
npm start
```
You should see:
```
Server running on port 5000
MongoDB Connected: cluster0-shard-00-xx.xxxxx.mongodb.net
```

### Step 5: Open the Frontend
Open `frontend/index.html` in your browser. The app will connect to the backend API at `http://localhost:5000`.

---

## 📡 API Endpoints

| Method | Endpoint | Description | Auth Required |
|---|---|---|---|
| `POST` | `/api/auth/register` | Register a new user | ❌ No |
| `POST` | `/api/auth/login` | Login & get JWT token | ❌ No |
| `POST` | `/api/orders` | Create a new order | ✅ Yes |
| `GET` | `/api/orders` | Get all orders (with filters) | ✅ Yes |
| `GET` | `/api/orders/:id` | Get single order by Order ID | ✅ Yes |
| `PATCH` | `/api/orders/:id/status` | Update order status | ✅ Yes |
| `DELETE` | `/api/orders/:id` | Delete an order | ✅ Yes |
| `GET` | `/api/orders/dashboard/stats` | Dashboard statistics | ✅ Yes |

### Query Filters for `GET /api/orders`
- `?status=RECEIVED`
- `?customerName=Rahul`
- `?phoneNumber=9876`
- `?garmentType=shirt`

---

## ✅ Features Implemented

### Core Features
- [x] **Create Order** — Customer name, phone, garments (type, qty, price), total bill, unique Order ID
- [x] **Order Status Management** — RECEIVED → PROCESSING → READY → DELIVERED
- [x] **View Orders** — List all orders with filters (status, name, phone, garment type)
- [x] **Basic Dashboard** — Total orders, total revenue, orders per status, recent orders

### Bonus Features
- [x] ✅ Simple Frontend (HTML/CSS/JS with dark theme UI)
- [x] ✅ Authentication (JWT-based login/register)
- [x] ✅ Database (MongoDB Atlas - cloud hosted)
- [x] ✅ Search by garment type
- [x] ✅ Estimated delivery date (auto-calculated: 3 days from order)
- [ ] 🔲 Deployment (not yet deployed — would use Render + Netlify)

---

## 📸 Screenshots

| Dashboard | New Order |
|---|---|
| ![Dashboard](screenshots/dashboard.png) | ![New Order](screenshots/create-order.png) |

| All Orders | Pricing |
|---|---|
| ![All Orders](screenshots/all-orders.png) | ![Pricing](screenshots/pricing.png) |

> 📝 Add actual screenshots after running the application.

---

## ⚖️ Tradeoffs & Decisions

### What I Chose & Why
| Decision | Reasoning |
|---|---|
| **Vanilla JS** over React | Faster to ship within 72 hours; demonstrates core fundamentals |
| **MongoDB Atlas** over local DB | Zero setup for reviewers; accessible from anywhere |
| **JWT auth** over session-based | Stateless, works well with REST APIs, easy to implement |
| **Single HTML file** for frontend | Quick to build and demo; no build tools required |
| **Hardcoded garment prices** | Matches assignment spec; keeps things simple |

### What I Skipped
- **Unit / Integration tests** — Prioritized core functionality within the time limit
- **Input sanitization (XSS)** — Used innerHTML in places; would add DOMPurify in production
- **Pagination** — Not needed for the scale of this project
- **Role-based access** — Single user type; would add admin/staff roles if scaling

### What I'd Improve With More Time
- Add **comprehensive test suite** (Jest + Supertest for API)
- Rebuild frontend in **React** with component architecture
- Add **pagination and sorting** for orders list
- Implement **role-based access control** (Admin, Staff)
- Add **order history / audit log** for status changes
- Add **export to CSV/PDF** for billing reports
- Deploy to **Render (backend) + Netlify (frontend)**
- Add **real-time updates** with WebSockets

---

## 🤖 AI Usage Report

👉 See the detailed AI Usage Report: **[AI_USAGE_REPORT.md](AI_USAGE_REPORT.md)**

---

## 📬 API Testing (Postman)

A Postman collection is included: **`postman_collection.json`**

### How to use:
1. Import `postman_collection.json` into Postman
2. Run **Register** or **Login** request first
3. Copy the `token` from the response
4. Update the `token` variable in the collection
5. All other requests will use this token automatically

---

## 🛠️ Project Structure

```
CleanSlate/
├── backend/
│   ├── config/
│   │   └── db.js              # MongoDB connection
│   ├── middleware/
│   │   └── auth.js            # JWT authentication middleware
│   ├── models/
│   │   ├── Order.js           # Order schema (Mongoose)
│   │   └── User.js            # User schema with password hashing
│   ├── routes/
│   │   ├── auth.js            # Register & Login endpoints
│   │   └── orders.js          # Order CRUD + Dashboard stats
│   ├── .env.example           # Environment variables template
│   ├── .gitignore
│   ├── package.json
│   └── server.js              # Express server entry point
├── frontend/
│   └── index.html             # CleanSlate UI (connects to API)
├── screenshots/               # App screenshots for README
├── postman_collection.json    # Postman API collection
├── AI_USAGE_REPORT.md         # Detailed AI usage documentation
└── README.md                  # This file
```

---

## 📜 License

This project was built for educational/assignment purposes.

---

**Built with ❤️ and AI assistance by Pratik Anil Salgude**

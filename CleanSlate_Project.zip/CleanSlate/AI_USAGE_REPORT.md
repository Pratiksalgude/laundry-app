# 🤖 AI Usage Report — CleanSlate

This document details how AI tools were used during the development of CleanSlate, as required by the assignment.

---

## 🔧 Tools Used

| Tool | Version | How I Used It |
|---|---|---|
| **ChatGPT** (GPT-4) | Web | Primary tool — scaffolding, code generation, debugging |
| **GitHub Copilot** | VS Code Extension | Inline code suggestions, auto-completing functions |
| **Microsoft Copilot** | Web | Code review, documentation writing, project analysis |

---

## 💬 Sample Prompts Used

### Prompt 1 — Initial Scaffolding
> *"Build a laundry order management system as a single-page HTML app with a dark theme. It should have: a sidebar navigation, a dashboard with stats cards, a create order form with garment selection and live billing, an orders table with filters, and a pricing page. Use vanilla HTML, CSS, and JavaScript with localStorage for data."*

**Result:** AI generated 80% of the initial frontend structure. I modified the styling, fixed responsive layout issues, and improved the UX.

---

### Prompt 2 — Backend API Setup
> *"Create a Node.js Express backend with MongoDB (Mongoose) for a laundry order management system. Include models for User and Order, JWT authentication, and CRUD routes for orders. The Order should have: orderId (auto-generated), customerName, phoneNumber, garments array, totalBill, status (RECEIVED/PROCESSING/READY/DELIVERED), and estimatedDelivery."*

**Result:** AI generated a working Express server with all routes. I had to fix the MongoDB connection error handling and add proper input validation.

---

### Prompt 3 — Authentication
> *"Add JWT-based authentication to my Express app. Create a User model with bcryptjs password hashing, register and login routes that return JWT tokens, and a protect middleware that verifies the Bearer token on protected routes."*

**Result:** The generated auth flow worked, but the middleware was sending double responses when the token was missing (it didn't `return` after the error response). I fixed this.

---

### Prompt 4 — Dashboard Statistics
> *"Create a GET /api/orders/dashboard/stats endpoint that returns: total number of orders, total revenue (sum of all totalBill), and a breakdown of orders by status (RECEIVED, PROCESSING, READY, DELIVERED)."*

**Result:** Worked correctly on first try. Clean aggregation logic.

---

### Prompt 5 — Connecting Frontend to Backend
> *"Update my vanilla JS frontend to use fetch() API calls to a backend at http://localhost:5000/api instead of localStorage. Add a login/register page that stores the JWT token. All order operations should include the Authorization header."*

**Result:** AI generated the fetch calls, but several had issues: missing `Content-Type` headers, incorrect error handling, and the login form didn't clear on success. I fixed all of these manually.

---

### Prompt 6 — Postman Collection
> *"Generate a Postman v2.1 collection JSON file for my CleanSlate API with all 8 endpoints. Include example request bodies and use a {{token}} variable for authentication."*

**Result:** The generated collection was mostly correct but had formatting issues in the JSON structure. I validated and fixed it manually.

---

## ✅ What AI Got Right

1. **Project structure** — Clean separation of models, routes, middleware, and config
2. **Mongoose schemas** — Proper validation, enums, and pre-save hooks
3. **JWT auth flow** — Register → Hash password → Login → Verify → Generate token
4. **CSS dark theme** — Professional color palette with CSS variables and responsive design
5. **CRUD operations** — All create, read, update, delete logic was functional
6. **Dashboard aggregation** — Revenue calculation and status grouping worked first try
7. **Postman collection format** — Correct v2.1 schema structure

---

## ❌ What AI Got Wrong

### Bug 1: Double Response in Auth Middleware
**Issue:** The `protect` middleware didn't `return` after sending the 401 error for missing tokens, causing Express to send two responses and crash.
```javascript
// AI Generated (broken):
if (!token) {
  res.status(401).json({ message: 'Not authorized' });
}
// Code below would still execute!

// My Fix:
if (!token) {
  return res.status(401).json({ message: 'Not authorized' });
}
```

### Bug 2: NaN in Billing Calculation
**Issue:** When the quantity input was empty or cleared by the user, `parseInt('')` returned `NaN`, making the total bill `NaN`.
```javascript
// AI Generated (broken):
const qty = parseInt(r.querySelector('.g-qty').value);

// My Fix:
const qty = parseInt(r.querySelector('.g-qty').value) || 0;
```

### Bug 3: Auto-Pricing Not Updating
**Issue:** The auto-price function was supposed to update the price field when the garment type changed, but the `onchange` event wasn't wired correctly in the dynamically created rows.
```javascript
// My Fix: Added explicit onchange handler in the addRow() function
// and ensured autoPrice() also calls updateBill()
```

### Bug 4: innerHTML XSS Vulnerability
**Issue:** AI used `innerHTML` to render user-provided customer names directly, creating a potential XSS vulnerability.
```javascript
// AI Generated (unsafe):
td.innerHTML = order.customerName;

// Awareness: In production, would use DOMPurify or textContent
```

### Bug 5: localStorage Fallback Syntax
**Issue:** AI generated `||` fallback for JSON parsing that would fail if the stored value was corrupted/invalid JSON.
```javascript
// AI Generated:
function load() { return JSON.parse(localStorage.getItem('orders') || '[]') }

// Improved to handle corrupted data:
function load() {
  try { return JSON.parse(localStorage.getItem('orders')) || []; }
  catch { return []; }
}
```

### Bug 6: Dashboard Not Refreshing After Status Update
**Issue:** After updating an order status in the orders table, the dashboard stats didn't refresh until you manually navigated away and back.
```javascript
// My Fix: Called renderDash() after every updateStatus() call
```

---

## 🔧 What I Fixed / Improved Manually

| Issue | AI Generated | My Improvement |
|---|---|---|
| Auth middleware double response | No `return` statement | Added `return` before error response |
| NaN billing | No fallback for empty inputs | Added `|| 0` fallback |
| Auto-pricing | Static event binding | Dynamic `onchange` in `addRow()` |
| XSS risk | Raw `innerHTML` | Awareness documented; would add DOMPurify |
| JSON parse crash | Simple `||` fallback | `try/catch` wrapper |
| Dashboard sync | No auto-refresh | Called `renderDash()` after status updates |
| Phone validation | No validation | Added regex pattern check |
| Responsive sidebar | Broken on mobile | Fixed width and icon-only mode |

---

## 📚 Key Takeaways

1. **AI is a powerful scaffolding tool** — It saved 3-4 hours of boilerplate code writing
2. **AI-generated code always needs review** — Every file had at least 1-2 bugs or improvements needed
3. **Edge cases are AI's weakness** — Empty inputs, error handling, and race conditions were consistently missed
4. **Documentation prompts work well** — AI generated clean README templates and API docs
5. **Iterative prompting is key** — Starting broad, then narrowing down with follow-up prompts gave the best results
6. **Human judgment is irreplaceable** — Architecture decisions, UX choices, and security awareness still required manual thinking

---

*This report was written honestly to reflect actual AI usage during development.*

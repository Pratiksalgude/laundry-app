@echo off
color 0B
title Install Node.js
echo.
echo  ============================================================
echo     📥 Node.js Installer for CleanSlate
echo  ============================================================
echo.

:: Check if already installed
where node >nul 2>nul
if %errorlevel% equ 0 (
    for /f "tokens=*" %%i in ('node --version') do set NODE_VER=%%i
    echo  ✅ Node.js is already installed: %NODE_VER%
    echo  You're good to go! Run setup_everything.bat next.
    echo.
    pause
    exit
)

echo  Node.js is not installed. Attempting automatic installation...
echo.

:: Method 1: winget (Windows 10/11 built-in)
echo  [Method 1] Trying winget (Windows Package Manager)...
where winget >nul 2>nul
if %errorlevel% equ 0 (
    echo  Found winget! Installing Node.js LTS...
    winget install OpenJS.NodeJS.LTS --accept-package-agreements --accept-source-agreements
    if %errorlevel% equ 0 (
        echo.
        echo  ════════════════════════════════════════════════════
        echo  ✅ Node.js installed successfully!
        echo  ⚠️  IMPORTANT: Close ALL terminal windows and
        echo     open a NEW one for changes to take effect.
        echo  Then run: setup_everything.bat
        echo  ════════════════════════════════════════════════════
        pause
        exit
    )
    echo  winget install failed. Trying next method...
    echo.
)

:: Method 2: Chocolatey
echo  [Method 2] Trying Chocolatey...
where choco >nul 2>nul
if %errorlevel% equ 0 (
    echo  Found Chocolatey! Installing Node.js LTS...
    choco install nodejs-lts -y
    if %errorlevel% equ 0 (
        echo.
        echo  ════════════════════════════════════════════════════
        echo  ✅ Node.js installed successfully!
        echo  ⚠️  Close this window, open a new terminal,
        echo     then run: setup_everything.bat
        echo  ════════════════════════════════════════════════════
        pause
        exit
    )
    echo  Chocolatey install failed. Trying next method...
    echo.
)

:: Method 3: Direct download
echo  [Method 3] Opening Node.js download page...
echo.
echo  ════════════════════════════════════════════════════════════
echo   📥 MANUAL INSTALLATION REQUIRED
echo  ════════════════════════════════════════════════════════════
echo.
echo   1. Download Node.js LTS from the page opening now
echo   2. Run the .msi installer
echo   3. ✅ CHECK "Add to PATH" during installation
echo   4. Click Next → Next → Install → Finish
echo   5. Close ALL terminal windows
echo   6. Open a NEW terminal
echo   7. Run: setup_everything.bat
echo.
echo  ════════════════════════════════════════════════════════════
start https://nodejs.org/en/download/
echo.
pause

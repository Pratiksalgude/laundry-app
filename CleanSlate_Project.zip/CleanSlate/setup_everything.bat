@echo off
color 0A
title CleanSlate - One-Click Setup
echo.
echo  ============================================================
echo     🧺  CleanSlate — Laundry Management System
echo     📦  One-Click Setup Script
echo  ============================================================
echo.

:: ── Step 1: Check Node.js ────────────────────────────────────
echo  [1/6] Checking Node.js...
where node >nul 2>nul
if %errorlevel% neq 0 (
    echo.
    echo  ❌ Node.js is NOT installed!
    echo  📥 Attempting to install Node.js automatically...
    echo.
    
    :: Try winget first (Windows 10/11)
    where winget >nul 2>nul
    if %errorlevel% equ 0 (
        echo  Using Windows Package Manager (winget)...
        winget install OpenJS.NodeJS.LTS --accept-package-agreements --accept-source-agreements
        if %errorlevel% equ 0 (
            echo  ✅ Node.js installed successfully via winget!
            echo  ⚠️  Please CLOSE this window and run setup_everything.bat AGAIN.
            echo     (PATH needs to refresh)
            pause
            exit
        )
    )
    
    :: Try chocolatey
    where choco >nul 2>nul
    if %errorlevel% equ 0 (
        echo  Using Chocolatey...
        choco install nodejs-lts -y
        if %errorlevel% equ 0 (
            echo  ✅ Node.js installed successfully via Chocolatey!
            echo  ⚠️  Please CLOSE this window and run setup_everything.bat AGAIN.
            pause
            exit
        )
    )
    
    :: Manual fallback
    echo.
    echo  ⚠️  Could not auto-install. Opening download page...
    echo  👉 Download Node.js LTS from: https://nodejs.org/
    echo  👉 Run the installer, check "Add to PATH", then run this script again.
    start https://nodejs.org/en/download/
    echo.
    pause
    exit
) else (
    for /f "tokens=*" %%i in ('node --version') do set NODE_VER=%%i
    echo  ✅ Node.js found: %NODE_VER%
)

:: ── Step 2: Check npm ────────────────────────────────────────
echo  [2/6] Checking npm...
where npm >nul 2>nul
if %errorlevel% neq 0 (
    echo  ❌ npm not found! Please reinstall Node.js from https://nodejs.org/
    pause
    exit
) else (
    for /f "tokens=*" %%i in ('npm --version') do set NPM_VER=%%i
    echo  ✅ npm found: v%NPM_VER%
)

:: ── Step 3: Install Backend Dependencies ─────────────────────
echo.
echo  [3/6] Installing backend dependencies...
cd /d "%~dp0backend"
if not exist "package.json" (
    echo  ❌ package.json not found in backend folder!
    echo  Make sure you're running this from the CleanSlate root folder.
    pause
    exit
)
call npm install
if %errorlevel% neq 0 (
    echo  ❌ npm install failed!
    pause
    exit
)
echo  ✅ Dependencies installed successfully!

:: ── Step 4: Setup .env file ──────────────────────────────────
echo.
echo  [4/6] Setting up environment variables...
if not exist ".env" (
    echo.
    echo  ============================================================
    echo   📝 .env file not found! Let's create one.
    echo  ============================================================
    echo.
    echo  You need a MongoDB Atlas connection string.
    echo  (If you don't have one yet, see setup_mongodb_guide.txt)
    echo.
    set /p MONGO_URI="  Enter your MongoDB URI: "
    echo.
    set /p JWT_SECRET="  Enter a JWT secret key (or press Enter for default): "
    if "%JWT_SECRET%"=="" set JWT_SECRET=cleanslate_super_secret_key_2024
    
    echo MONGO_URI=%MONGO_URI%> .env
    echo JWT_SECRET=%JWT_SECRET%>> .env
    echo PORT=5000>> .env
    
    echo.
    echo  ✅ .env file created!
) else (
    echo  ✅ .env file already exists!
)

:: ── Step 5: Start Backend Server ─────────────────────────────
echo.
echo  [5/6] Starting backend server...
echo.
echo  ============================================================
echo   🚀 Server starting on http://localhost:5000
echo   📋 API docs: See README.md
echo  ============================================================
echo.

:: ── Step 6: Open Frontend ────────────────────────────────────
echo  [6/6] Opening frontend in browser...
cd /d "%~dp0"
start "" "%~dp0frontend\index.html"
echo  ✅ Frontend opened in browser!
echo.
echo  ============================================================
echo   ✅ Setup Complete! Server is running below.
echo   Press Ctrl+C to stop the server.
echo  ============================================================
echo.

:: Start the server (this blocks — keeps running)
cd /d "%~dp0backend"
call node server.js
pause
